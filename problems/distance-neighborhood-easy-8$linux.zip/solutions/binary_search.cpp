#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    long long K;
    cin >> n >> K;

    vector<long long> a(n);
    for (auto &x : a) cin >> x;
    sort(a.begin(), a.end());

    // Start with one neighborhood
    int neighborhoods = 1;

    // Every time the gap exceeds K, we start a new neighborhood
    for (int i = 1; i < n; i++) {
        if (a[i] - a[i-1] > K) {
            neighborhoods++;
        }
    }

    cout << neighborhoods << "\n";
    return 0;
}
