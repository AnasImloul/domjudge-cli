#include <bits/stdc++.h>
using namespace std;

struct DSU {
    vector<int> p, r;
    DSU(int n): p(n), r(n,0) { iota(p.begin(), p.end(), 0); }
    int find(int x){ return p[x] == x ? x : p[x] = find(p[x]); }
    void unite(int a, int b){
        a = find(a); b = find(b);
        if(a == b) return;
        if(r[a] < r[b]) swap(a,b);
        p[b] = a;
        if(r[a] == r[b]) r[a]++;
    }
};

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, K;
    cin >> N >> K;
    vector<int> pos(N);
    for(int i = 0; i < N; i++){
        cin >> pos[i];
    }


    DSU dsu(N);
    // brute‐force all pairs
    for(int i = 0; i < N; i++){
        for(int j = i+1; j < N; j++){
            if (abs(pos[i] - pos[j]) <= K) {
                dsu.unite(i, j);
            }
        }
    }

    // count distinct roots = number of connected components
    unordered_set<int> roots;
    roots.reserve(N);
    for(int i = 0; i < N; i++){
        roots.insert(dsu.find(i));
    }

    cout << roots.size() << "\n";
    return 0;
}
