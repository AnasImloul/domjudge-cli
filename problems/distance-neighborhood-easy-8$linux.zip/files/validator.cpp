#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);

    // Read N & K
    int N = inf.readInt(1, 200'000, "N");
    inf.readSpace();
    int K = inf.readInt(1, 1'000'000'000, "K");
    inf.readEoln();

    for (int i = 0; i < N; i++) {
        if (i > 0) inf.readSpace();
        int x = inf.readInt(0, 1'000'000'000, "x");
    }

    inf.readEoln();
    inf.readEof();
    return 0;
}
