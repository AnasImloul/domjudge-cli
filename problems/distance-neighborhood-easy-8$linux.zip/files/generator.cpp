#include "testlib.h"
#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);

    // Command-line parameters:
    // 1) seed for rnd
    // 2) N: number of people
    // 3) N_RANGE: gives coordinate absolute bound (positions ∈ [−N_RANGE, +N_RANGE])
    // 4) K_RANGE: maximum K value (we pick a random K ∈ [1, K_RANGE])
    int SEED     = opt<int>(1);
    int N        = opt<int>(2);
    int N_RANGE  = opt<int>(3);
    int K_RANGE  = opt<int>(4);

    // Reseed the generator
    rnd.setSeed(SEED + N + N_RANGE + K_RANGE);

    int COORD_MIN = 0;
    int COORD_MAX =  N_RANGE;
    int K_MIN     = 1;
    int K_MAX     = K_RANGE;

    // Generate N distinct positions
    set<int> pos_set;
    while ((int)pos_set.size() < N) {
        pos_set.insert(rnd.next(COORD_MIN, COORD_MAX));
    }

    vector<int> positions(pos_set.begin(), pos_set.end());
    shuffle(positions.begin(), positions.end());

    // Pick a single K
    int K = rnd.next(K_MIN, K_MAX);

    // Output in the new format:
    // First line: N K
    // Second line: the N distinct positions
    cout << N << " " << K << "\n";
    for (int i = 0; i < N; i++) {
        cout << positions[i] << (i + 1 == N ? "\n" : " ");
    }

    return 0;
}
