#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define endl '\n'
#define tc     \
    ll tc;     \
    cin >> tc; \
    while (tc--)
#define pb push_back
#define mp make_pair
const ll MOD = 1e9 + 7;

void fastio()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
}

void solve()
{
    ll N, L;
    cin >> N >> L;
    vector<ll> A(N);
    ll ai;
    ll sum = 0;
    for(int i = 0; i < N; i++){
        cin >> ai;
        sum += ai;
        A[i] = -ai;
    }
    if( sum != L){
        A.push_back(sum - L);
    }
    priority_queue<ll> pq(A.begin(), A.end());
    ll ans = 0;
    while(pq.size() > 1){
        ll x1 = pq.top();
        pq.pop();
        ll x2 = pq.top();
        pq.pop();
        ans -= (x1 + x2);
        pq.push(x1 + x2);
    }
    cout << ans << "\n";

}

int main()
{
    fastio();
    ll t = 1;
    // cin >> t;
    for (ll i = 1; i <= t; i++)
    {
        solve();
    }

    return 0;
}