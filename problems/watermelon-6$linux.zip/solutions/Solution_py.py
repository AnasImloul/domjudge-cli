import heapq

def solve():
    N, L = map(int, input().split())
    A = list(map(int, input().split()))
    heapq.heapify(A)

    total = sum(A)
    if total != L:
        heapq.heappush(A, L - total)
        
    
    ans = 0

    while len(A) > 1:
        x1 = heapq.heappop(A)
        x2 = heapq.heappop(A)
        cost = x1 + x2
        ans += cost 
        heapq.heappush(A, cost)

    print(ans)

if __name__ == "__main__":
    solve()