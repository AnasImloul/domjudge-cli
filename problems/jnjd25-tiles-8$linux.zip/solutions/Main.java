import java.io.*;
import java.util.*;


public class Main {
	static PrintWriter out;
	static Reader in;
	public static void main(String[] args) throws Exception {
		input_output();
		Main solver = new Main();
		solver.solve();
		out.close();
 
		out.flush();
	} 


	static ArrayList<Integer> adj[];
	static long[] fm, fim;
	static int[] size;

	static int MOD = 1_000_000_000 + 7;
	static int MAX = 1_000_000_000;
	static int MAXN = 2_00_000 + 1;

	void solve() throws Exception {
		int t = in.nextInt();

		while (t --> 0) {
			int width = in.nextInt(),
				aWidth = in.nextInt(),
				bWidth = in.nextInt(),
				aCount = in.nextInt(),
				bCount = in.nextInt();

			// Count the min required A tiles to solve
			int minA = -1;
			for (int i = 0; i <= width && i*aWidth <= width; i++) {
				int left = width - i*aWidth;
				if (left%bWidth == 0) {
					minA = i;
					break;
				}
			}

			// Count the min required B tiles to solve
			int minB = -1;
			for (int i = 0; i <= width && i*bWidth <= width; i++) {
				int left = width - i*bWidth;
				if (left%aWidth == 0) {
					minB = i;
					break;
				}
			}

			long low = 0, high = 2*1_000_000_000, mid = 0, ans = 0;
			while (low <= high) {
				mid = (low+high)/2;
				if (check(mid, width, aWidth, bWidth, aCount, bCount, minA, minB)) {
					low = mid+1;
					ans = mid;
				} else {
					high = mid-1;
				}
			}

			out.println(ans);
		}
	}

	static boolean check(long mid, long width, long aWidth, long bWidth, long aCount, long bCount, long minA, long minB) {
		if (minA == -1 && minB == -1) return false;
		if (minA == -1) {
			long reach = (width/bWidth)/bCount;
			if (reach >= mid) return true;
			else return false;
		}
		if (minB == -1) {
			long reach = (width/aWidth)/aCount;
			if (reach >= mid) return true;
			else return false;
		}

		aCount -= minA * mid;
		bCount -= minB * mid;
		if (aCount < 0 || bCount < 0) return false;

		long common = (aWidth*bWidth) / gcd(aWidth, bWidth);

		long totalNeeds = ((width - (minA * aWidth) - (minB * bWidth)) / common) * mid;
		long have = (aCount != 0 ? aCount/(common/aWidth) : 0) + (bCount != 0 ? bCount/(common/bWidth) : 0);

		if (have >= totalNeeds) return true;
		else return false;
	}

	static long gcd(long a, long b) {
        if (b == 0)
            return a;
        else
            return gcd(b, a % b);
    }

	static class Reader {
		private InputStream mIs;
		private byte[] buf = new byte[1024];
		private int curChar;
		private int numChars;
 
		public Reader() {
			this(System.in);
		}
 
		public Reader(InputStream is) {
			mIs = is;
		}
 
		public int read() {
			if (numChars == -1) {
				throw new InputMismatchException();
 
			}
			if (curChar >= numChars) {
				curChar = 0;
				try {
					numChars = mIs.read(buf);
				} catch (IOException e) {
					throw new InputMismatchException();
				}
				if (numChars <= 0) {
					return -1;
				}
			}
			return buf[curChar++];
		}
 
		public String nextLine() {
			int c = read();
			while (isSpaceChar(c)) {
				c = read();
			}
			StringBuilder res = new StringBuilder();
			do {
				res.appendCodePoint(c);
				c = read();
			} while (!isEndOfLine(c));
			return res.toString();
		}
 
		public String next() {
			int c = read();
			while (isSpaceChar(c)) {
				c = read();
			}
			StringBuilder res = new StringBuilder();
			do {
				res.appendCodePoint(c);
				c = read();
			} while (!isSpaceChar(c));
			return res.toString();
		}
 
		double nextDouble() {
			return Double.parseDouble(next());
		}
 
		public long nextLong() {
			int c = read();
			while (isSpaceChar(c)) {
				c = read();
			}
			int sgn = 1;
			if (c == '-') {
				sgn = -1;
				c = read();
			}
			long res = 0;
			do {
				if (c < '0' || c > '9') {
					throw new InputMismatchException();
				}
				res *= 10;
				res += c - '0';
				c = read();
			} while (!isSpaceChar(c));
			return res * sgn;
		}
 
		public int nextInt() {
			int c = read();
			while (isSpaceChar(c)) {
				c = read();
			}
			int sgn = 1;
			if (c == '-') {
				sgn = -1;
				c = read();
			}
			int res = 0;
			do {
				if (c < '0' || c > '9') {
					throw new InputMismatchException();
				}
				res *= 10;
				res += c - '0';
				c = read();
			} while (!isSpaceChar(c));
			return res * sgn;
		}
 
		public boolean isSpaceChar(int c) {
			return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
		}
 
		public boolean isEndOfLine(int c) {
			return c == '\n' || c == '\r' || c == -1;
		}
 
	}
	static void input_output() throws IOException {
		File f = new File("in.txt");
		if (f.exists() && !f.isDirectory()) {
			in = new Reader(new FileInputStream("in.txt"));
		} else in = new Reader();
		f = new File("out.txt");
		if (f.exists() && !f.isDirectory()) {
			out = new PrintWriter(new File("out.txt"));
		} else out = new PrintWriter(System.out);
	}
}