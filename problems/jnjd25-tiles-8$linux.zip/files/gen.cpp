#include "testlib.h"
#include <iostream>
 
using namespace std;
 
int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
 
    int t = stoi(argv[1]);
    int x = stoi(argv[2]);
    int maxWidth = stoi(argv[3]);
    int maxCount = stoi(argv[4]);
    
    cout << t << endl;
    
    while (t --> 0) {
        int aWidth = rnd.next(1, maxWidth);
        int bWidth = rnd.next(1, maxWidth);
        int aCount = rnd.next(1, maxCount);
        int bCount = rnd.next(1, maxCount);
        cout << x << " " << aWidth << " " << bWidth << " " << aCount << " " << bCount << endl;
    }
}
