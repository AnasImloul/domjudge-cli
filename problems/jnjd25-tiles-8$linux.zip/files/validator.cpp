#include <bits/stdc++.h>
#include "testlib.h"
 
 
int main(int argc, char* argv[]) {
    registerValidation(argc, argv);
    
    int T = inf.readInt(1, 100'000, "T");
    inf.readEoln();
    
    int test = 1;
    int sumOfX = 0;
    int sumOfAWidth = 0;
    int sumOfBWidth = 0;
    
    while (T --> 0) {
        setTestCase(test);
        int x = inf.readInt(1, 100'000, "x"); sumOfX += x; inf.readSpace();
        int aWidth = inf.readInt(1, 100'000, "aWidth"); sumOfAWidth += aWidth; inf.readSpace();
        int bWidth = inf.readInt(0, 100'000, "bWidth"); sumOfBWidth += bWidth; inf.readSpace();
        int aCount = inf.readInt(0, 1'000'000'000, "aCount"); inf.readSpace();
        int bCount = inf.readInt(0, 1'000'000'000, "bCount"); inf.readEoln();
        
        test++;
    }
 
    ensuref(sumOfX <= 300'000, "sum of x over all test cases > 300000");
    ensuref(sumOfAWidth <= 300'000, "sum of aWidth over all test cases > 300000");
    ensuref(sumOfBWidth <= 300'000, "sum of bWidth over all test cases > 300000");
    inf.readEof();
}
