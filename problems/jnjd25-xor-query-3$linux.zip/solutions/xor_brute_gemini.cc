#include <iostream>
#include <vector>
#include <numeric> // Not strictly needed here, but common for sum/xor
#include <cmath>   // For std::pow, though bit shift is used for 2^N

// Modulo constant from the problem
const int MOD = 1e9 + 7;

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int n, q;
    std::cin >> n >> q;

    std::vector<long long> a(n);
    for (int i = 0; i < n; ++i) {
        std::cin >> a[i];
    }

    // Store queries to process them
    std::vector<long long> queries(q);
    for (int i = 0; i < q; ++i) {
        std::cin >> queries[i];
    }

    // Process each query
    for (int qi = 0; qi < q; ++qi) {
        long long target_x = queries[qi];
        long long count_for_this_x = 0;

        // Number of possible subsets is 2^n
        // 1ULL << n correctly computes 2^n for n up to 63
        unsigned long long num_subsets = 1ULL << n;

        // Iterate through all numbers from 0 to 2^n - 1
        // Each number 'i' represents a subset
        for (unsigned long long i = 0; i < num_subsets; ++i) {
            long long current_xor_sum = 0;
            int current_subset_size = 0;

            // Check which elements are in the subset represented by 'i'
            for (int j = 0; j < n; ++j) {
                // If the j-th bit of 'i' is set, then a[j] is in the current subset
                if ((i >> j) & 1) {
                    current_xor_sum ^= a[j];
                    current_subset_size++;
                }
            }

            // Check if the conditions are met
            if (current_xor_sum == target_x && current_subset_size % 2 == 0) {
                count_for_this_x++;
            }
        }
        // Output the result for the current query modulo MOD
        std::cout << count_for_this_x % MOD << '\n';
    }

    return 0;
}