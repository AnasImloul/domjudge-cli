#include <bits/stdc++.h>
using namespace std;

const int MOD = 1e9 + 7;

struct Basis {
    vector<pair<long long, int>> basis;

    Basis() {
        basis.resize(61, {0, 0});
    }

    void insert(long long a) {
        int current_parity = 1;
        long long current_mask = a;

        for (int i = 60; i >= 0; --i) {
            if ((current_mask >> i) & 1) {
                if (basis[i].first == 0) {
                    basis[i].first = current_mask;
                    basis[i].second = current_parity;
                    break;
                } else {
                    current_mask ^= basis[i].first;
                    current_parity ^= basis[i].second;
                }
            }
        }
    }

    pair<bool, int> check(long long x) {
        long long current_mask = x;
        int p = 0;
        for (int i = 60; i >= 0; --i) {
            if ((current_mask >> i) & 1) {
                if (basis[i].first == 0) {
                    return {false, 0};
                }
                current_mask ^= basis[i].first;
                p ^= basis[i].second;
            }
        }
        return {current_mask == 0, p};
    }

    int size() {
        int cnt = 0;
        for (int i = 0; i <= 60; ++i) {
            if (basis[i].first != 0) {
                cnt++;
            }
        }
        return cnt;
    }
};

long long pow_mod(long long base, long long exponent, long long mod) {
    long long result = 1;
    base %= mod;
    while (exponent > 0) {
        if (exponent % 2 == 1) {
            result = (result * base) % mod;
        }
        base = (base * base) % mod;
        exponent /= 2;
    }
    return result;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    int n, q;
    cin >> n >> q;

    vector<long long> a(n);
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }

    Basis basis;
    for (long long num : a) {
        basis.insert(num);
    }

    int k = basis.size();
    int s = n - k;

    long long ans_even = 0;
    if (s > 0) {
        ans_even = pow_mod(2, s - 1, MOD);
    }

    while (q--) {
        long long x;
        cin >> x;

        auto [found, p] = basis.check(x);
        if (!found) {
            cout << 0 << '\n';
            continue;
        }

        if (s > 0) {
            cout << ans_even << '\n';
        } else {
            cout << (p % 2 == 0 ? 1 : 0) << '\n';
        }
    }

    return 0;
}