#include "testlib.h"
#include <iostream>
#include <cstdlib>

using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);

    // Configurable parameters with defaults
    int N = atoi(argv[1]);
    int Q = atoi(argv[2]);
    long long max_val_param = atoll(argv[3]);

    cout << N << " " << Q << endl;

    for (int i = 0; i < N; ++i) {
        long long int x = rnd.next(0LL, max_val_param);
        cout << x << (i == N - 1 ? "" : " ");
    }
    cout << endl;

    for (int i = 0; i < Q; ++i) {
        long long int x = rnd.next(0LL, max_val_param);
        cout << x << "\n";
    }

    return 0;
}
