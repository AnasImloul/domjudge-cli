#include "testlib.h"
#include <set>
#include <utility>
#include <string>
#include <vector>
#include <iostream>
#include <random>
#include <chrono>

using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);

    // Configurable parameters with defaults
    int N = atoi(argv[1]);
    int Q = atoi(argv[2]);
    long long max_val_param = atoll(argv[3]); // Use atoll for long long

    cout << N << " " << Q << endl;

    unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
    std::mt19937_64 generator(seed);

    // Distribution for generating numbers in the range [0, max_val_param]
    std::uniform_int_distribution<long long> distribution(0, max_val_param);

    for (int i = 0; i < N; ++i) {
        long long int x = distribution(generator); // New way
        cout << x << (i == N - 1 ? "" : " ");
    }
    cout << endl;

    for (int i = 0; i < Q; ++i) {
        long long int x = distribution(generator); // New way
        cout << x << "\n";
    }

    return 0;
}