#include <iostream>

using namespace std;

const int ALPHABETS_COUNT = 26;

struct Trie {
public:
    Trie() {
        root = new TrieNode();
    }

    void insert(const string& word) {
        if (contains(word)) return;  // No duplicates (matches first solution)
        TrieNode* current = root;
        for (const auto& c : word) {
            if (!current->children[index(c)]) {
                current->children[index(c)] = new TrieNode();
            }
            current = current->children[index(c)];
            current->successors++;  // Only increment for new words
        }
        current->isWord = true;
    }

    bool remove(const string& word) {
        if (!contains(word)) return false;
        TrieNode* current = root;
        current->successors--;  // Decrement root first
        for (const auto& c : word) {
            current = current->children[index(c)];
            current->successors--;  // Decrement all nodes in the path
        }
        current->isWord = false;
        return true;
    }

    int count(const string& prefix) {
        TrieNode* current = root;
        for (const auto& c : prefix) {
            if (!current->children[index(c)]) return 0;
            current = current->children[index(c)];
        }
        return current->successors;  // O(1) lookup
    }

private:
    static constexpr inline int index(const char& c) { return c - 'a'; }

    bool contains(const string& word) {
        TrieNode* current = root;
        for (const auto& c : word) {
            if (!current->children[index(c)]) return false;
            current = current->children[index(c)];
        }
        return current->isWord;
    }

    struct TrieNode {
        TrieNode* children[ALPHABETS_COUNT] = {nullptr};
        bool isWord = false;      // Marks end of a live word
        int successors = 0;       // Count of live words under this node
    };

    TrieNode* root;
};

int main() {
    Trie trie;
    int t;
    cin >> t;
    while (t--) {
        string cmd, word;
        cin >> cmd >> word;
        if (cmd == "INSERT") {
            trie.insert(word);
        } else if (cmd == "DELETE") {
            cout << (trie.remove(word) ? "DELETED" : "NOT FOUND") << endl;
        } else { // COUNT
            cout << trie.count(word) << endl;
        }
    }
    return 0;
}