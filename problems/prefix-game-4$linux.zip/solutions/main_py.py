ALPHABETS_COUNT = 26

class TrieNode:
    def __init__(self):
        self.children = [None] * ALPHABETS_COUNT
        self.is_word = False
        self.successors = 0  # Count of live words under this node

class Trie:
    def __init__(self):
        self.root = TrieNode()

    def _index(self, c):
        return ord(c) - ord('a')

    def _contains(self, word):
        current = self.root
        for c in word:
            idx = self._index(c)
            if current.children[idx] is None:
                return False
            current = current.children[idx]
        return current.is_word

    def insert(self, word):
        if self._contains(word):
            return  # No duplicates
        current = self.root
        for c in word:
            idx = self._index(c)
            if current.children[idx] is None:
                current.children[idx] = TrieNode()
            current = current.children[idx]
            current.successors += 1  # Only increment for new words
        current.is_word = True

    def remove(self, word):
        if not self._contains(word):
            return False
        current = self.root
        current.successors -= 1  # Decrement root first
        for c in word:
            idx = self._index(c)
            current = current.children[idx]
            current.successors -= 1  # Decrement all nodes in the path
        current.is_word = False
        return True

    def count(self, prefix):
        current = self.root
        for c in prefix:
            idx = self._index(c)
            if current.children[idx] is None:
                return 0
            current = current.children[idx]
        return current.successors  # O(1) lookup

def main():
    trie = Trie()
    t = int(input())
    for _ in range(t):
        cmd, word = input().split()
        if cmd == "INSERT":
            trie.insert(word)
        elif cmd == "DELETE":
            print("DELETED" if trie.remove(word) else "NOT FOUND")
        else:  # COUNT
            print(trie.count(word))

if __name__ == "__main__":
    main()
