#include <iostream>
#include <vector>
#include <unordered_map>
#include <unordered_set>

#define endl "\n"

using namespace std;

unordered_map<string, int> prefixCount;
unordered_set<string> words;

int main() {
  int q; cin >> q;

  while (q--) {
    string type, word; cin >> type >> word;

    if (type == "INSERT") {
      if (!words.count(word)) {
        string temp;
        for (const auto &c : word) {
          temp += c;
          prefixCount[temp]++;
        }
        words.insert(word);
      }
    } else if (type == "DELETE") {
      if (!words.count(word)) {
        cout << "NOT FOUND" << endl;
      } else {
        string temp;
        for (const auto &c : word) {
          temp += c;
          prefixCount[temp]--;
        }
        words.erase(temp);
        cout << "DELETED" << endl;
      }
    } else if (type == "COUNT") {
      cout << prefixCount[word] << endl;
    }
  }
}