#include <iostream>
#include <bits/stdc++.h>

using namespace std;

#define ALPHABETS_COUNT 26

struct TrieNode {
    TrieNode* children[ALPHABETS_COUNT];
    bool prefixIsWord;
};

TrieNode* createNode() {
    TrieNode* newNode = new TrieNode;
    newNode->prefixIsWord = false;
    for (int i = 0; i < ALPHABETS_COUNT; i++)
        newNode->children[i] = NULL;
    return newNode;
}

void insert(TrieNode* root, const string& word) {
    TrieNode* current = root;
    for (char ch : word) {
        int idx = ch - 'a';
        if (!current->children[idx])
            current->children[idx] = createNode();
        current = current->children[idx];
    }
    current->prefixIsWord = true;
}

bool remove(TrieNode* root, const string& word) {
    TrieNode* current = root;
    for (char ch : word) {
        int idx = ch - 'a';
        if (!current->children[idx])
            return false;
        current = current->children[idx];
    }
    if (current->prefixIsWord) {
        current->prefixIsWord = false;
        return true;
    }
    return false;
}

int count(TrieNode* root, const string& prefix) {
    TrieNode* current = root;
    for (char ch : prefix) {
        int idx = ch - 'a';
        if (!current->children[idx])
            return 0;
        current = current->children[idx];
    }

    int result = 0;
    queue<TrieNode*> q;
    q.push(current);

    while (!q.empty()) {
        TrieNode* node = q.front();
        q.pop();
        if (node->prefixIsWord)
            result++;
        for (int i = 0; i < ALPHABETS_COUNT; i++) {
            if (node->children[i])
                q.push(node->children[i]);
        }
    }

    return result;
}

int main() {
    TrieNode* root = createNode();
    int t;
    cin >> t;
    while (t--) {
        string cmd, word;
        cin >> cmd >> word;
        if (cmd == "INSERT") {
            insert(root, word);
        } else if (cmd == "DELETE") {
            cout << (remove(root, word) ? "DELETED" : "NOT FOUND") << endl;
        } else { // COUNT
            cout << count(root, word) << endl;
        }
    }
    return 0;
}
