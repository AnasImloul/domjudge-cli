#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

int main(int argc, char* argv[]) {
    // Usage: generator <number_of_queries>
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " <number_of_queries>\n";
        return 1;
    }

    registerGen(argc, argv, 1);
    long long Q = atoll(argv[1]);
    // Infer max length L so that Q * L ≈ 1e6
    long long L = 1000000LL / max(1LL, Q);

    // Buffers for operations
    vector<string> inserts;
    vector<string> counts;
    inserts.reserve(Q);
    counts.reserve(Q);

    // Generate operations
    for (long long i = 0; i < Q; i++) {
        int t = rnd.next(0, 1);
        if (t == 0) {
            // INSERT: random-length word up to L
            long long len = rnd.next(1LL, L);
            string s;
            s.reserve(len);
            // first character is 'a'
            s.push_back('a');
            // remaining characters random 'a'..'z'
            for (long long j = 1; j < len; j++) {
                char c = char('a' + rnd.next(0, 25));
                s.push_back(c);
            }
            inserts.push_back(s);
        } else {
            // COUNT: single-character query 'a'
            counts.push_back("a");
        }
    }

    // Output total queries
    cout << Q << "\n";

    // First all INSERT operations
    for (const auto& s : inserts) {
        cout << "INSERT " << s << "\n";
    }
    // Then all COUNT operations
    for (const auto& c : counts) {
        cout << "COUNT " << c << "\n";
    }

    return 0;
}
