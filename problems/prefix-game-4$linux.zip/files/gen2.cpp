#include <bits/stdc++.h>
using namespace std;

const int TOTAL_OPS = 200000;
const int MAX_LEN = 100;
const int OP_INSERT = 0;
const int OP_DELETE = 1;
const int OP_COUNT = 2;

// Fixed seed for deterministic output
mt19937 rng(123456789);

string generate_ab_string(int len) {
    string s;
    for (int i = 0; i < len; i++) {
        s += (rng() % 2) ? 'a' : 'b';
    }
    return s;
}

string generate_deep_ab_string(int depth, char start) {
    string s;
    s += start;
    for (int i = 1; i < depth; i++) {
        s += (s.back() == 'a') ? 'b' : 'a';
    }
    return s;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    // Operation distribution weights
    vector<int> op_weights = {20, 20, 60}; // INSERT, DELETE, COUNT
    
    // Pre-compute all operations first for determinism
    vector<pair<int, string>> operations;
    vector<string> inserted_words;
    vector<string> deep_prefixes;
    
    // Generate fixed set of deep prefixes
    for (int i = 0; i < 20; i++) {
        deep_prefixes.push_back(generate_deep_ab_string(10 + i, (i % 2) ? 'a' : 'b'));
    }

    // Generate all operations in advance
    for (int i = 0; i < TOTAL_OPS; i++) {
        int op_type = 0;
        int r = rng() % 100;
        if (r < op_weights[0]) op_type = OP_INSERT;
        else if (r < op_weights[0] + op_weights[1]) op_type = OP_DELETE;
        else op_type = OP_COUNT;

        string operand;
        switch (op_type) {
            case OP_INSERT: {
                operand = (rng() % 10 < 3) 
                    ? generate_deep_ab_string(10 + (rng() % 20), (rng() % 2) ? 'a' : 'b')
                    : generate_ab_string(1 + (rng() % MAX_LEN));
                // Ensure no trailing spaces
                operand.erase(remove_if(operand.begin(), operand.end(), ::isspace), operand.end());
                inserted_words.push_back(operand);
                break;
            }
            case OP_DELETE: {
                if (!inserted_words.empty() && rng() % 3 != 0) {
                    int idx = rng() % inserted_words.size();
                    operand = inserted_words[idx];
                    inserted_words.erase(inserted_words.begin() + idx);
                } else {
                    operand = generate_ab_string(1 + (rng() % 10));
                }
                // Ensure no trailing spaces
                operand.erase(remove_if(operand.begin(), operand.end(), ::isspace), operand.end());
                break;
            }
            case OP_COUNT: {
                int choice = rng() % 10;
                if (choice < 6) {
                    operand = deep_prefixes[rng() % deep_prefixes.size()];
                } else if (choice < 9) {
                    operand = generate_ab_string(1 + (rng() % 10));
                }
                // else empty operand
                // Ensure no trailing spaces
                operand.erase(remove_if(operand.begin(), operand.end(), ::isspace), operand.end());
                break;
            }
        }
        operations.emplace_back(op_type, operand);
    }

    // Output all operations with strict formatting
    cout << TOTAL_OPS << "\n";
    for (auto& [op, operand] : operations) {
        switch (op) {
            case OP_INSERT: 
                cout << "INSERT " << operand << "\n"; 
                break;
            case OP_DELETE: 
                cout << "DELETE " << operand << "\n"; 
                break;
            case OP_COUNT: 
                cout << "COUNT " << operand << "\n"; 
                break;
        }
    }

    return 0;
}