#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

int main(int argc, char* argv[]) {
    // Usage: generator <Q> <max_length> <alphabet_size>
    if (argc != 4) {
        cerr << "Usage: " << argv[0] << " <number_of_queries> <max_word_length> <alphabet_size>\n";
        return 1;
    }

    registerGen(argc, argv, 1);
    int Q      = atoi(argv[1]);
    int maxLen = atoi(argv[2]);
    int alpha  = atoi(argv[3]);
    alpha = max(1, min(alpha, 26));  // clamp to [1,26]

    cout << Q << "\n";

    static const char* ops[3] = {"INSERT", "DELETE", "COUNT"};
    vector<string> pool;
    pool.reserve(Q/2);

    for (int i = 0; i < Q; i++) {
        int t = rnd.next(0, 2);
        const char* op = ops[t];

        if (t == 0) {
            // INSERT: generate word, store in pool
            int len = rnd.next(1, maxLen);
            len = max(len, rnd.next(1, maxLen));
            len = max(len, rnd.next(1, maxLen));
            string s;
            s.reserve(len);
            for (int j = 0; j < len; j++)
                s.push_back(char('a' + rnd.next(0, alpha - 1)));
            cout << "INSERT " << s << "\n";
            pool.push_back(s);
        }
        else if (t == 1) {
            // DELETE: 80% chance from existing pool (if nonempty), else fresh random
            cout << "DELETE ";
            bool useExisting = !pool.empty() && rnd.next(1, 5) == 1;
            if (useExisting) {
                int idx = rnd.next(0, int(pool.size()) - 1);
                cout << pool[idx] << "\n";
                // O(1) removal:
                pool[idx] = pool.back();
                pool.pop_back();
            } else {
                int len = rnd.next(1, maxLen);
                len = max(len, rnd.next(1, maxLen));
                len = max(len, rnd.next(1, maxLen));
                string s;
                s.reserve(len);
                for (int j = 0; j < len; j++)
                    s.push_back(char('a' + rnd.next(0, alpha - 1)));
                cout << s << "\n";
            }
        }
        else {
            // COUNT: bias towards shorter strings with triangular distribution
            int len = rnd.next(1, maxLen);
            len = min(len, rnd.next(1, maxLen));
            len = min(len, rnd.next(1, maxLen));
            string s;
            s.reserve(len);
            for (int j = 0; j < len; j++)
                s.push_back(char('a' + rnd.next(0, alpha - 1)));
            cout << "COUNT " << s << "\n";
        }
    }

    return 0;
}
