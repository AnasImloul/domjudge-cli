#include "testlib.h"
#include <iostream>
#include <string>

using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int t = rnd.next(1, 100000); // number of operations
    cout << t << '\n';
    for (int i = 0; i < t; ++i) {
        int op = rnd.next(0, 2);
        string s;
        int len = rnd.next(1, 50); // string length
        for (int j = 0; j < len; ++j) {
            s += rnd.next(0, 1) ? 'a' : 'b';
        }
        if (op == 0) {
            cout << "INSERT " << s << '\n';
        } else if (op == 1) {
            cout << "DELETE " << s << '\n';
        } else {
            cout << "COUNT " << s << '\n';
        }
    }
    return 0;
}