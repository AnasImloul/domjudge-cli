#include "testlib.h"

int main() {
    registerValidation(); // Initialize testlib for input validation

    // Read the number of galaxies (n) and validate its range: 2 <= n <= 1000
    int n = inf.readInt(2, 1000, "n");
    inf.readEoln(); // Expect end of line after reading n

    // Read data for each of the n galaxies
    for (int i = 0; i < n; ++i) {
        // Read X_i and validate its range: -1000 <= X_i <= 1000
        inf.readInt(-1000, 1000, "X_i");
        inf.readSpace(); // Expect a space separating values on the same line

        // Read Y_i and validate its range: -1000 <= Y_i <= 1000
        inf.readInt(-1000, 1000, "Y_i");
        inf.readSpace(); // Expect a space

        // Read VX_i and validate its range: -1000 <= VX_i <= 1000
        inf.readInt(-1000, 1000, "VX_i");
        inf.readSpace(); // Expect a space

        // Read VY_i and validate its range: -1000 <= VY_i <= 1000
        inf.readInt(-1000, 1000, "VY_i");

        // Expect end of line after reading all four values for the galaxy
        inf.readEoln();
    }

    // Read the closeness radius (R) and validate its range: 0 <= R <= 10^9
    // Use LL suffix to explicitly specify long long literals
    inf.readLong(0LL, 1000000000LL, "R"); // 10^9
    inf.readEoln(); // Expect end of line after reading R

    // Expect end of file after the last line (the line with R)
    inf.readEof();

    // If the validator reaches this point without calling ensure() implicitly
    // (by range check or format error), the input is considered valid.
    // testlib will automatically print "Validation passed".

    return 0;
}