#include "testlib.h"
#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <set> // Required for type 6

using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1); // Initialize testlib generator. Arg 1 is the version number.

    // Read the test case type from command line arguments
    // Example usage: ./gen 1, ./gen 2, ./gen 3, etc.
    int type = atoi(argv[1]);

    int n;
    long long R;
    vector<tuple<int, int, int, int>> galaxies; // X, Y, VX, VY

    // Define ranges for coordinates and velocities
    const int MAX_COORD_VEL = 1000;
    const long long MAX_R = 1000000000LL;

    if (type == 1) {
        // Type 1: Small random test
        n = rnd.next(2, 10);
        R = rnd.next(0LL, 100LL);
        for (int i = 0; i < n; ++i) {
            galaxies.emplace_back(
                rnd.next(-10, 10), rnd.next(-10, 10),
                rnd.next(-5, 5), rnd.next(-5, 5)
            );
        }
    } else if (type == 2) {
        // Type 2: Medium random test
        n = rnd.next(50, 200);
        R = rnd.next(0LL, 10000LL);
        for (int i = 0; i < n; ++i) {
            galaxies.emplace_back(
                rnd.next(-100, 100), rnd.next(-100, 100),
                rnd.next(-20, 20), rnd.next(-20, 20)
            );
        }
    } else if (type == 3) {
        // Type 3: Large random test (potential TLE/precision issues)
        n = rnd.next(800, 1000);
        R = rnd.next(MAX_R / 2, MAX_R); // Large R
        for (int i = 0; i < n; ++i) {
            galaxies.emplace_back(
                rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL), rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL),
                rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL), rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL)
            );
        }
    } else if (type == 4) {
        // Type 4: Edge case - All galaxies identical
        n = rnd.next(2, 1000);
        R = rnd.next(0LL, MAX_R);
        int x = rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL);
        int y = rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL);
        int vx = rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL);
        int vy = rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL);
        for (int i = 0; i < n; ++i) {
            galaxies.emplace_back(x, y, vx, vy);
        }
    } else if (type == 5) {
        // Type 5: Edge case - All galaxies at (0,0), random velocities
        n = rnd.next(2, 1000);
        R = rnd.next(0LL, MAX_R);
        for (int i = 0; i < n; ++i) {
            galaxies.emplace_back(
                0, 0,
                rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL), rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL)
            );
        }
    } else if (type == 6) {
        // Type 6: Edge case - Different initial positions, same velocity
        n = rnd.next(2, 1000);
        R = rnd.next(0LL, MAX_R);
        int vx = rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL);
        int vy = rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL);
        set<pair<int, int>> initial_positions;
        while (initial_positions.size() < (size_t)n) { // Ensure size is less than n (size_t)
            initial_positions.insert({rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL), rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL)});
        }
        for (const auto& pos : initial_positions) {
            galaxies.emplace_back(pos.first, pos.second, vx, vy);
        }
    } else if (type == 7) {
        // Type 7: Edge case - Designed to create specific quadratic roots
        // Generate 2 galaxies that will have interesting distance functions
        n = 2; // Start with 2 specific galaxies
        R = rnd.next(1LL, 100LL); // R > 0 to potentially have intervals
        // Example pair creating |t^2-1|*2 <= R type curves
        // dVX=1, dX=-1, dVY=1, dY=-1
        // G1: X=0, VX=1, Y=0, VY=1
        // G2: X=1, VX=0, Y=1, VY=0
        galaxies.emplace_back(0, 0, 1, 1);
        galaxies.emplace_back(1, 1, 0, 0);

        // Add more galaxies with random values to make it harder, ensuring n up to 1000
        int remaining_n = rnd.next(0, 998); // Add up to 998 more galaxies
        n += remaining_n;
         for (int i = 0; i < remaining_n; ++i) {
            galaxies.emplace_back(
                rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL), rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL),
                rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL), rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL)
            );
        }

    } else if (type == 8) {
        // Type 8: Maximum constraints
        n = 1000;
        R = MAX_R;
        for (int i = 0; i < n; ++i) {
            galaxies.emplace_back(
                rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL), rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL),
                rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL), rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL)
            );
        }
    } else if (type == 9) {
        // Type 9: Minimum constraints
        n = 2;
        R = 0LL;
        galaxies.emplace_back(0, 0, 0, 0);
        galaxies.emplace_back(rnd.next(-10, 10), rnd.next(-10, 10), rnd.next(-5, 5), rnd.next(-5, 5)); // Make G2 potentially different
        // Ensure they don't start at the exact same point unless R > 0
        if (R == 0 && get<0>(galaxies[0]) == get<0>(galaxies[1]) && get<1>(galaxies[0]) == get<1>(galaxies[1])) {
             get<2>(galaxies[1])++; // Shift G2 slightly if R=0 and they overlap initially
        }

    } else if (type == 10) {
        // Type 10: Cases likely to generate many overlapping intervals
        // Create many pairs of galaxies that are initially close and have small relative velocities
        n = rnd.next(100, 300); // Moderate number of galaxies
        // Ensure n is even to make pairing easier, or handle the last one
        if (n % 2 != 0) n++;
        if (n > 1000) n = 1000;


        R = rnd.next(100LL, 1000LL); // Moderate R

        galaxies.reserve(n); // Reserve space for n galaxies

        for (int i = 0; i < n / 2; ++i) {
             // Create pair 1
             int x1 = rnd.next(-100, 100);
             int y1 = rnd.next(-100, 100);
             int vx1 = rnd.next(-10, 10);
             int vy1 = rnd.next(-10, 10);
             galaxies.emplace_back(x1, y1, vx1, vy1);

             // Create pair 2, close to pair 1
             int x2 = x1 + rnd.next(-5, 5);
             int y2 = y1 + rnd.next(-5, 5);
             int vx2 = vx1 + rnd.next(-2, 2);
             int vy2 = vy1 + rnd.next(-2, 2);

             // Ensure they are distinct galaxies
             if (x1==x2 && y1==y2 && vx1==vx2 && vy1==vy2) x2++; // Simple way to make them distinct

             galaxies.emplace_back(x2, y2, vx2, vy2);
        }


    } else {
        // Default or invalid type: Basic random test
        n = rnd.next(2, 100);
        R = rnd.next(0LL, 1000LL);
        for (int i = 0; i < n; ++i) {
            galaxies.emplace_back(
                rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL), rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL),
                rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL), rnd.next(-MAX_COORD_VEL, MAX_COORD_VEL)
            );
        }
    }

    // Output the generated test case
    cout << n << endl;
    for (const auto& gal : galaxies) {
        cout << get<0>(gal) << " " << get<1>(gal) << " " << get<2>(gal) << " " << get<3>(gal) << endl;
    }
    cout << R << endl;

    return 0;
}