#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <map>
#include <set>


using LD = long double;

const LD INF = 1e18; 
const LD EPS = 1e-9; 

struct Galaxy {
    long long X, Y, VX, VY;
};

struct Interval {
    LD start, end;
};


int compare(LD a, LD b) {
    if (a < b - EPS) return -1;
    if (a > b + EPS) return 1;
    return 0;
}


struct CompareLD {
    bool operator()(const LD& a, const LD& b) const {
        return compare(a, b) < 0;
    }
};



std::vector<Interval> solve_quadratic(LD a, LD b, LD c) {
    std::vector<Interval> solutions;

    if (compare(a, 0) == 0) { 
        if (compare(b, 0) == 0) { 
            if (c <= EPS) { 
                solutions.push_back({0, INF});
            } else { 
                
            }
        } else { 
            
            if (b > 0) { 
                LD root = -c / b;
                 if (compare(root, 0) >= 0) { 
                     solutions.push_back({0, root});
                 }
            } else { 
                LD root = -c / b;
                 if (compare(root, 0) <= 0) { 
                     solutions.push_back({0, INF});
                 } else { 
                     solutions.push_back({root, INF});
                 }
            }
        }
    } else { 
        LD delta = b * b - 4 * a * c;

        if (compare(delta, 0) < 0) { 
            if (a > EPS) { 
               
            } else { 
                 solutions.push_back({0, INF});
            }
        } else { 
            LD sqrt_delta = (delta < EPS) ? 0 : std::sqrt(delta);
            LD root1 = (-b - sqrt_delta) / (2 * a);
            LD root2 = (-b + sqrt_delta) / (2 * a);

            if (compare(root1, root2) > 0) std::swap(root1, root2); 

            if (a > EPS) { 
                LD start = std::max((LD)0.0, root1);
                LD end = root2;
                if (compare(start, end) < 0) {
                     solutions.push_back({start, end});
                }
            } else {
                LD start1 = 0;
                LD end1 = root1;
                 if (compare(start1, end1) < 0) {
                     solutions.push_back({start1, end1});
                 }

              
                LD start2 = std::max((LD)0.0, root2);
                LD end2 = INF;
                 if (compare(start2, end2) < 0) {
                     solutions.push_back({start2, end2});
                 }
            }
        }
    }
    return solutions;
}


Interval intersect_intervals(Interval i1, Interval i2) {
    LD start = std::max(i1.start, i2.start);
    LD end = std::min(i1.end, i2.end);
     if (compare(start, end) < 0) {
        return {start, end};
    } else {
        return {INF, INF}; // Represent empty intersection
    }
}


std::vector<Interval> merge_intervals(std::vector<Interval>& intervals) {
    if (intervals.empty()) {
        return {};
    }

    
    intervals.erase(std::remove_if(intervals.begin(), intervals.end(),
        [](const Interval& i){ return compare(i.start, i.end) >= 0 || compare(i.start, 0) < 0; }), intervals.end());

    if (intervals.empty()) {
        return {};
    }

    std::sort(intervals.begin(), intervals.end(), [](const Interval& a, const Interval& b){
        int cmp_start = compare(a.start, b.start);
        if (cmp_start != 0) return cmp_start < 0;
        return compare(a.end, b.end) < 0; // For same start, sort by end
    });

    std::vector<Interval> merged;
    merged.push_back(intervals[0]);

    for (size_t i = 1; i < intervals.size(); ++i) {
        if (compare(intervals[i].start, merged.back().end) <= 0) { // Overlap or touch
            merged.back().end = std::max(merged.back().end, intervals[i].end);
        } else {
            merged.push_back(intervals[i]);
        }
    }
    return merged;
}


int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int n;
    std::cin >> n;

    std::vector<Galaxy> galaxies(n);
    for (int i = 0; i < n; ++i) {
        std::cin >> galaxies[i].X >> galaxies[i].Y >> galaxies[i].VX >> galaxies[i].VY;
    }

    long long R_ll;
    std::cin >> R_ll;
    LD R = R_ll;

    std::vector<Interval> all_valid_intervals;

    for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            long long dX_ll = galaxies[i].X - galaxies[j].X;
            long long dY_ll = galaxies[i].Y - galaxies[j].Y;
            long long dVX_ll = galaxies[i].VX - galaxies[j].VX;
            long long dVY_ll = galaxies[i].VY - galaxies[j].VY;

            LD dX = dX_ll;
            LD dY = dY_ll;
            LD dVX = dVX_ll;
            LD dVY = dVY_ll;

            std::vector<LD> crit_times;
            crit_times.push_back(0.0); // Start of time
          
            if (compare(dVX, 0) != 0) {
                LD t_x = -dX / dVX;
                 if (compare(t_x, 0) >= 0) crit_times.push_back(t_x);
            }
             if (compare(dVY, 0) != 0) {
                LD t_y = -dY / dVY;
                 if (compare(t_y, 0) >= 0) crit_times.push_back(t_y);
            }
            crit_times.push_back(INF); 

            std::sort(crit_times.begin(), crit_times.end());
            crit_times.erase(std::unique(crit_times.begin(), crit_times.end(), [](LD a, LD b){ return std::abs(a - b) < EPS; }), crit_times.end());


            for (size_t k = 0; k < crit_times.size() - 1; ++k) {
                LD t_start_interval = crit_times[k];
                LD t_end_interval = crit_times[k+1];

                   LD test_t;
                if (compare(t_end_interval, INF) == 0) test_t = t_start_interval + 1.0;
                else test_t = (t_start_interval + t_end_interval) / 2.0;

              
                 if (compare(test_t, t_start_interval) == 0 && compare(t_start_interval, t_end_interval) < 0) test_t += EPS;
                 
                 if (compare(test_t, 0) < 0) test_t = 0;


               
                LD val_dX_test = dX + dVX * test_t;
                LD val_dY_test = dY + dVY * test_t;

                LD sign_dX = (compare(val_dX_test, 0) > 0) ? 1.0 : ((compare(val_dX_test, 0) < 0) ? -1.0 : 0.0);
                LD sign_dY = (compare(val_dY_test, 0) > 0) ? 1.0 : ((compare(val_dY_test, 0) < 0) ? -1.0 : 0.0);

                if (std::abs(dX) < EPS && std::abs(dVX) < EPS) sign_dX = 0;
                if (std::abs(dY) < EPS && std::abs(dVY) < EPS) sign_dY = 0;


                LD A_lin = sign_dX * dVX + sign_dY * dVY;
                LD B_lin = sign_dX * dX + sign_dY * dY;

                LD a_quad = A_lin;
                LD b_quad = A_lin + B_lin;
                LD c_quad = B_lin - R;

                std::vector<Interval> quad_solutions = solve_quadratic(a_quad, b_quad, c_quad);

               
                Interval current_interval = {t_start_interval, t_end_interval};

                for (const auto& sol_interval : quad_solutions) {
                     Interval intersection = intersect_intervals(current_interval, sol_interval);
                     if (compare(intersection.start, intersection.end) < 0) {
                        all_valid_intervals.push_back(intersection);
                     }
                }
            }
        }
    }

    std::vector<Interval> merged = merge_intervals(all_valid_intervals);

    std::set<LD, CompareLD> distinct_endpoints;

    for (const auto& interval : merged) {
        if (compare(interval.start, INF) < 0) { // Only add finite start points
            distinct_endpoints.insert(interval.start);
        }
        if (compare(interval.end, INF) < 0) { // Only add finite end points
             distinct_endpoints.insert(interval.end);
        }
    }

    std::cout << distinct_endpoints.size() << std::endl;

    return 0;
}