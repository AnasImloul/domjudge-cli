#include "testlib.h"
#include <vector>



using namespace std;

int RANGE = 1e9;


int main(int argc, char* argv[]) {
  registerGen(argc, argv, 1);

  // Parameters:
  // 1) N:         size of the array (1 ≤ N ≤ 2e5)
  // 2) pattern:   which kind of test to generate
  //                0 = fully random
  //                1 = strictly decreasing (always “Yes”)
  //                2 = one duplicate step (first violation)
  //                3 = strictly increasing (always “No” at i=2)
  //                4 = constant array
  //                5 = random with some violations sprinkled
  int N      = opt<int>(1);
  int pattern = opt<int>(2);

  vector<int> a(N);

  switch (pattern) {
  case 1: {
    // strictly decreasing
    int start = rnd.next(-RANGE + N, RANGE);
    int cur = start;
    for (int i = 0; i < N; i++) {
      a[i] = cur;
      // ensure gap at least 1
      cur -= rnd.next(1, 1000);
    }
    break;
  }
  case 2: {
    // strictly decreasing, then one duplicate => first violation
    int start = rnd.next(-RANGE + N, RANGE);
    int cur = start;
    for (int i = 0; i < N; i++) {
      a[i] = cur;
      if (i == N/2) {
        // duplicate previous element
        a[i] = a[i-1];
      } else {
        cur -= rnd.next(1, 1000);
      }
    }
    break;
  }
  case 3: {
    // strictly increasing
    int start = rnd.next(-RANGE, RANGE - N);
    int cur = start;
    for (int i = 0; i < N; i++) {
      a[i] = cur;
      cur += rnd.next(1, 1000);
    }
    break;
  }
  case 4: {
    // constant array
    int v = rnd.next(-RANGE, RANGE);
    for (int i = 0; i < N; i++) {
      a[i] = v;
    }
    break;
  }
  case 5: {
    // random with sprinkling of small prefix-min violations
    // first generate a random base, then occasionally reset to a bigger number
    int base = rnd.next(-RANGE, RANGE);
    a[0] = base;
    for (int i = 1; i < N; i++) {
      if (rnd.next(1, 10)) {
        // violation: pick a value >= current prefix-min
        a[i] = rnd.next(a[i-1], RANGE);
      } else {
        // keep decreasing
        a[i] = a[i-1] - rnd.next(1, 1000);
      }
    }
    break;
  }
  case 0:
  default: {
    // fully random
    for (int i = 0; i < N; i++) {
      a[i] = rnd.next(-RANGE, RANGE);
    }
    break;
  }
  }

  // Output the test
  cout << N << "\n";
  for (int i = 0; i < N; i++) {
    cout << a[i] << (i+1 < N ? ' ' : '\n');
  }
  return 0;
}
