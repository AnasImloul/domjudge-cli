#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    cin >> N;
    vector<long long> a(N);
    for (int i = 0; i < N; i++) {
        cin >> a[i];
    }

    if (N <= 1) {
        // A single element is trivially strictly decreasing
        cout << "Yes\n";
        return 0;
    }

    long long mn = a[0];
    for (int i = 1; i < N; i++) {
        if (a[i] < mn) {
            // new prefix minimum is strictly smaller
            mn = a[i];
        } else {
            // prefix-minimum does not strictly decrease here
            cout << "No\n";
            return 0;
        }
    }

    cout << "Yes\n";
    return 0;
}
