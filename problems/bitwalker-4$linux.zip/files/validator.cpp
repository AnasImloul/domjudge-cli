
#include "testlib.h"

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);

    int k = inf.readInt(1, 20, "k");
    inf.readSpace();

    long long limitX = (1LL << k) - 1; 
    long long x = inf.readLong(0, limitX, "x");
    inf.readSpace();

    long long n = inf.readLong(0, 1000000000LL - 1, "n");
    inf.readEoln();
    inf.readEof();

    return 0;
}