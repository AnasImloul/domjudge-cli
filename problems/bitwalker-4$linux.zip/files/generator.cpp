#include "testlib.h"
#include <iostream>

using namespace std;

static long long randll(long long lo, long long hi) { return rnd.next(lo, hi); }

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);

    long long seed = opt<long long>("s", opt<long long>("seed", -1));
    if (seed != -1) rnd.setSeed(seed);

    if (argc == 4 && argv[1][0] != '-') {
        int k = atoi(argv[1]);
        int x = atoi(argv[2]);
        long long n = atoll(argv[3]);
        println(k, x, n);
        return 0;
    }

    int group = opt<int>("g", opt<int>("group", -1));
    int k, x; long long n;

    switch (group) {
        case 0:  k = 1;  x = 0;                n = 0; break;
        case 1:  k = 1;  x = 1;                n = 1'000'000'000LL - 1; break;
        case 2:  k = 20; x = 0;                n = 0; break;
        case 3:  k = 20; x = (1 << 20) - 1;    n = 1'000'000'000LL - 1; break;
        case 4:  k = 20; x = (1 << 20) - 1;    n = 0; break;
        case 5:  k = rnd.next(1, 20);          x = 0; n = randll(0, 1'000'000'000LL - 1); break;
        case 6:  k = rnd.next(1, 20);          x = (1 << k) - 1; n = randll(0, 1'000'000'000LL - 1); break;
        case 7:  k = rnd.next(1, 20);          x = rnd.next(0, (1 << k) - 1); n = 1'000'000'000LL - 1; break;
        default: k = rnd.next(1, 20);          x = rnd.next(0, (1 << k) - 1); n = randll(0, 1'000'000'000LL - 1);
    }

    println(k, x, n);
    return 0;
}