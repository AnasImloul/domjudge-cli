#include <iostream>
#include <vector>

using namespace std;

int main() {

    int k;               
    unsigned int x;      
    long long n;         
    if (!(cin >> k >> x >> n)) return 0;

    const unsigned int MOD  = 1u << k;  
    const unsigned int MASK = MOD - 1;

    auto next = [&](unsigned int v) {
        return (v + __builtin_popcount(v)) & MASK;   
    };

    vector<int> first(MOD, -1);         
    vector<unsigned int> seq; seq.reserve(MOD + 1);

    unsigned int v = x;
    int mu = 0, lambda = 0;
    for (int step = 0; ; ++step) {
        if (first[v] != -1) {          
            mu = first[v];
            lambda = step - mu;
            break;
        }
        first[v] = step;
        seq.push_back(v);
        v = next(v);
    }
    seq.push_back(v);                  

    unsigned long long T = (unsigned long long)n * (n + 1) / 2ull;

    unsigned int ans;
    if (T < seq.size())                
        ans = seq[(size_t)T];
    else {
        unsigned long long idx = mu + (T - mu) % (unsigned long long)lambda; // Cycle offset
        ans = seq[(size_t)idx];
    }
    cout << ans << endl;
}