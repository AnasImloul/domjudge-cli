#include <iostream>

using namespace std;
using ll = long long;

ll solve(ll x, int k, ll n) {
    ll total_press = n * (n + 1) / 2;
    for (ll i = 0; i < total_press; i++) {
        x = (x + __builtin_popcountll(x)) % (1ULL << k);
    }
    return x;
}

int main() {
    int k;
    ll a, n;
    cin >> k >> a >> n;

    cout << solve(a, k, n) << endl;

    return 0;
}