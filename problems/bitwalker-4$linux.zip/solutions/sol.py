def solve(k, x, n):
    mod = pow(2, k)

    total = n * (n + 1) // 2

    used = set()
    values = [x]
    first_repeat = -1
    for _ in range(total):
        next_value = (values[-1] + values[-1].bit_count()) % mod
        if next_value in used:
            first_repeat  = next_value
            break
        used.add(next_value)
        values.append(next_value)
    else:
        return values[-1]

    cycle_start = values.index(first_repeat)
    cycle_length = len(values) - cycle_start

    return values[(total - cycle_start) % cycle_length + cycle_start]


if __name__ == "__main__":
    k, x, n = map(int, input().split())
    print(solve(k, x, n))