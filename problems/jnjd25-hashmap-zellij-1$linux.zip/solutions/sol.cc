#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

void solve() {
    string s;
    cin >> s;

    vector<int> counts(26, 0);
    for (char c : s) {
        counts[c - 'a']++;
    }

    int max_freq = 0;
    if (!s.empty()) {
        max_freq = *max_element(counts.begin(), counts.end());
    }

    int n = s.length();

    if (max_freq <= (n - max_freq) + 1) {
        cout << "YES" << endl;
    } else {
        cout << "NO" << endl;
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    int t;
    cin >> t;
    
    while (t--) {
        solve();
    }
    return 0;
}