#include "testlib.h"
#include <string>
#include <vector>
#include <numeric>
#include <algorithm>
#include <set>    


std::string generate_string(int len, bool make_yes_case) {
    if (len <= 0) { // Should not happen based on constraints 1 <= |s|
        len = 1;
    }

    std::vector<char> s_chars(len);
    char target_char = rnd.next('a', 'z'); // The character whose frequency we control
    int target_freq;

    if (len == 1) {
        // Length 1 string is always a "YES" case, e.g., "a".
        // max_freq = 1. (1 - 1) + 1 = 1.  1 <= 1 is true.
        s_chars[0] = target_char;
        // shuffle is not needed for len 1 but good practice if vector was built differently
        // shuffle(s_chars.begin(), s_chars.end()); 
        return std::string(s_chars.begin(), s_chars.end());
    }

    if (make_yes_case) {
        // For YES: max_freq <= (len + 1) / 2
        // Minimum possible max_freq is 1 (e.g. all distinct characters)
        target_freq = rnd.next(1, (len + 1) / 2);
    } else { // Make a "NO" case
        // For NO: max_freq > (len + 1) / 2
        // Smallest integer for max_freq is floor((len + 1) / 2) + 1
        int min_freq_for_no = ((len + 1) / 2) + 1;
        
        if (min_freq_for_no > len) { 
            // This condition implies it's impossible to make a "NO" case.
            // This only happens if len=1 (which is handled above).
            // If somehow reached for len > 1, it means an issue in logic,
            // but for safety, fallback to making a "YES" case.
            target_freq = rnd.next(1, (len + 1) / 2);
        } else {
            target_freq = rnd.next(min_freq_for_no, len);
        }
    }

    // Fill the beginning of the character vector with the target_char
    for (int i = 0; i < target_freq; ++i) {
        s_chars[i] = target_char;
    }

    // Prepare alphabet for other characters
    std::vector<char> other_chars_alphabet;
    for (char c = 'a'; c <= 'z'; ++c) {
        if (c != target_char) {
            other_chars_alphabet.push_back(c);
        }
    }

    // Fill the remaining characters
    for (int i = target_freq; i < len; ++i) {
        if (other_chars_alphabet.empty()) {
            // This would only happen if the alphabet was restricted to a single character
            // initially, which is not the case for 'a'-'z'.
            // If it did, we must fill with target_char, potentially changing the YES/NO property.
            s_chars[i] = target_char; 
        } else {
            // Pick a random character from the 'other' alphabet
            s_chars[i] = other_chars_alphabet[rnd.next(0, (int)other_chars_alphabet.size() - 1)];
        }
    }

    // Shuffle the characters to make the string random
    shuffle(s_chars.begin(), s_chars.end());
    return std::string(s_chars.begin(), s_chars.end());
}


int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);

    int n_min = 1;
    int n_max = 50;

    int num_test_cases = std::stoi(argv[1]); 

    println(num_test_cases); // Print the number of test cases

    // Generate specific initial test cases for edge/boundary conditions
    if (num_test_cases > 0) { // Test Case 1: Smallest possible string "a" (YES)
        println(generate_string(n_min, true));
    }
    
    if (num_test_cases > 1) { // Test Case 2: Smallest "NO" case "aa" (if n_max >= 2)
        if (n_max >= 2) {
            println(generate_string(2, false)); // This should generate "aa" or similar
        } else { // If n_max is 1, generate another smallest YES case
            println(generate_string(n_min, true));
        }
    }

    if (num_test_cases > 2) { // Test Case 3: Max length, try for YES
        println(generate_string(n_max, true));
    }
    
    if (num_test_cases > 3) { // Test Case 4: Max length, try for NO
        println(generate_string(n_max, false));
    }

    if (num_test_cases > 4) { // Test Case 5: String with all same characters (should be NO if len > 1)
        int len = rnd.next(std::max(2, n_min), n_max); // Ensure len >= 2 for a clear NO case
        if (len == 1) len = n_min; // If n_min=1, rnd could give 1. "a" is YES.
                               // We want a NO case, so ensure len >=2 if possible.
                               // If n_max = 1, this case will generate a "YES".
        if (len == 1 && n_max == 1) { // If only len 1 is possible
            println(generate_string(1, true));
        } else {
            len = std::max(2, len); // Force len >= 2 if n_max allows
            char c = rnd.next('a','z');
            std::string s(len, c);
            println(s);
        }
    }

    if (num_test_cases > 5) { // Test Case 6: String with all distinct characters (should be YES)
        int len = rnd.next(n_min, std::min(n_max, 26)); // Max 26 distinct chars
        std::string s = "";
        std::vector<char> p(26);
        for(int k=0; k<26; ++k) p[k] = (char)('a'+k);
        shuffle(p.begin(), p.end()); // Randomize which distinct chars are chosen
        for(int k=0; k<len; ++k) s += p[k];
        if (s.empty() && len > 0) { // Should not happen if len > 0
             s = generate_string(len, true); // Fallback
        } else if (s.empty() && len == 0){ // Should not happen
             s = generate_string(1, true);
        }
        println(s);
    }
    
    // Fill remaining test cases with a mix
    for (int i = 6; i < num_test_cases; ++i) {
        int len = rnd.next(n_min, n_max);
        bool make_yes = rnd.next(0, 1); // 0 or 1, for 50/50 chance
        println(generate_string(len, make_yes));
    }

    return 0;
}