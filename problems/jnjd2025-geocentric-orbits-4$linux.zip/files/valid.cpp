#include "testlib.h"

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);

    // Read number of planets
    int n = inf.readInt(2, 1000, "n");
    inf.readEoln();

    // Read each planet's T and A
    for (int i = 0; i < n; i++) {
        inf.readInt(1, 1000, "T_i");
        inf.readSpace();
        inf.readInt(0, 359, "A_i");
        inf.readEoln();
    }

    // There should be no extra data
    inf.readEof();
    return 0;
}
