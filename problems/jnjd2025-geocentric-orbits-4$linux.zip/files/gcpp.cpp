// generator.cpp
// Polygon‐style test generator for "Geocentric Orbits" problem using testlib

#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

int main(int argc, char* argv[]) {
    // argv[1] — test case index (1-based)
    registerGen(argc, argv, 1);

    int tc = atoi(argv[1]);  
    vector<vector<pair<int,int>>> edge = {
        // 1) n = 2, identical periods & angles
        { {1, 0}, {1, 0} },
        // 2) n = 2, different periods & maximal angle
        { {1, 0}, {2, 359} },
        // 3) n = 100, all T=1000, A=0
        vector<pair<int,int>>(100, {1000, 0}),
        // 4) n = 100, sequential T=1..100, A=i mod 360
        [](){
            vector<pair<int,int>> v;
            for(int i = 0; i < 100; i++)
                v.emplace_back(i+1, i%360);
            return v;
        }(),
    };

    vector<pair<int,int>> planets;
    if (tc <= (int)edge.size()) {
        planets = edge[tc-1];
    } else {
        // random cases for tc > edge.size()
        int n = rnd.next(2, 1000);
        planets.resize(n);
        for (int i = 0; i < n; i++) {
            planets[i].first  = rnd.next(1, 1000);  // T_i
            planets[i].second = rnd.next(0, 359);   // A_i
        }
    }

    // output
    cout << planets.size() << "\n";
    for (auto &p : planets) {
        cout << p.first << " " << p.second << "\n";
    }
    return 0;
}
