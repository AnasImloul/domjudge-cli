#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    const int MAX_DAYS = 1'000'000;
    const int FULL_CIRCLE = 360 * 360;  // scale factor so that FULL_CIRCLE / T[i] is integer

    int n;
    cin >> n;

    vector<int> T(n), angle(n), step(n);
    for (int i = 0; i < n; i++) {
        cin >> T[i] >> angle[i];
        // scale the initial angle into [0, FULL_CIRCLE):
        angle[i] = (angle[i] * 360) % FULL_CIRCLE;
        // precompute the per-day increment (must be integer):
        step[i] = FULL_CIRCLE / T[i];
    }

    // simulate day by day
    for (int day = 1; day <= MAX_DAYS; day++) {
        // advance each planet
        for (int i = 0; i < n; i++) {
            angle[i] = (angle[i] + step[i]) % FULL_CIRCLE;
        }
        // check if all angles are now equal
        bool all_equal = true;
        for (int i = 1; i < n; i++) {
            if (angle[i] != angle[0]) {
                all_equal = false;
                break;
            }
        }
        if (all_equal) {
            cout << day << "\n";
            return 0;
        }
    }

    // if we never saw a full alignment within MAX_DAYS
    cout << -1 << "\n";
    return 0;
}
