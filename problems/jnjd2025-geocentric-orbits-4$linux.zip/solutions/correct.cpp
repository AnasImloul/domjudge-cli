#include <bits/stdc++.h>
using namespace std;
using i64 = long long;

// extended gcd: returns g = gcd(a,b), and finds x,y with a*x + b*y = g
i64 extgcd(i64 a, i64 b, i64 &x, i64 &y) {
    if (b==0) { x= (a>=0?1:-1); y=0; return a*x; }
    i64 x1,y1;
    i64 g = extgcd(b, a%b, x1, y1);
    x = y1;
    y = x1 - (a/b)*y1;
    return g;
}

// solve D * d ≡ C  (mod M), return minimal positive d, or -1 if none ≤ MAXD
i64 solve_congruence(i64 D, i64 C, i64 M) {
    // normalize into [0,M)
    D = (D % M + M) % M;
    C = (C % M + M) % M;
    i64 x, y;
    i64 g = extgcd(D, M, x, y);
    if (C % g) return -1;            // no solution
    // reduce
    D /= g;  C /= g;  M /= g;
    // now D * d ≡ C  (mod M), with gcd(D,M)=1
    // particular solution d0 = x * C  (mod M)
    i64 d0 = (x % M + M) % M;
    d0 = (d0 * C) % M;
    // if d0==0, the first positive solution is M
    return d0 == 0 ? M : d0;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    const int MAXD = 1'000'000;
    const i64 M = 360LL * 360LL;

    int n;
    cin >> n;
    vector<i64> T(n), A(n), step(n);
    for(int i = 0; i < n; i++){
        cin >> T[i] >> A[i];
        A[i] = (A[i] * 360) % M;            // scale initial angle
        step[i] = (360 * 360) / T[i];       // integer daily increment
    }

    i64 answer = LLONG_MAX;
    // check every unordered pair
    for(int i = 0; i < n; i++){
        for(int j = i+1; j < n; j++){
            // we want step[i]*d + A[i] ≡ step[j]*d + A[j]  (mod M)
            // ⇔ (step[i] - step[j]) * d ≡ (A[j] - A[i])  (mod M)
            i64 D = step[i] - step[j];
            i64 C = A[j] - A[i];
            i64 d = solve_congruence(D, C, M);
            if (d > 0 && d <= MAXD)
                answer = min(answer, d);
        }
    }

    cout << (answer == LLONG_MAX ? -1 : answer) << "\n";
    return 0;
}
